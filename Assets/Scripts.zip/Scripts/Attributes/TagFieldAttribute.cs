﻿using UnityEngine;

/// <summary>
/// Atributo para marcar campos de tipo string que deben mostrar un dropdown de tags
/// </summary>
public class TagFieldAttribute : PropertyAttribute
{
}

